from unittest import TestCase, main

from project.social_media import SocialMedia


class TestSocialMedia(TestCase):
    def setUp(self):
        self.sm = SocialMedia('Joe', 'Instagram', 100, 'some type')

    def test_valid_init(self):
        self.assertEqual(self.sm._username, 'Joe')
        self.assertEqual(self.sm._platform, 'Instagram')
        self.assertEqual(self.sm._followers, 100)
        self.assertEqual(self.sm._content_type,'some type')
        self.assertEqual(self.sm._posts, [])

    def test_init_with_wrong_platform_type(self):
        with self.assertRaises(ValueError) as ve:
            sm = SocialMedia('Joe', 123, 100,'some type')

        self.assertEqual(str(ve.exception), "Platform should be one of ['Instagram', 'YouTube', 'Twitter']")

    def test_init_with_less_than_zero_followers(self):
        with self.assertRaises(ValueError) as ve:
            sm = SocialMedia('Joe', 'Instagram', -5,'some type')

        self.assertEqual(str(ve.exception), "Followers cannot be negative.")

    def test_create_post_func(self):
        result = self.sm.create_post('some content')

        self.assertEqual(len(self.sm._posts), 1)
        self.assertEqual(self.sm._posts[0]['content'],'some content')
        self.assertEqual(self.sm._posts[0]['likes'], 0)
        self.assertEqual(self.sm._posts[0]['comments'], [])

        self.assertEqual("New some type post created by Joe on Instagram.", result)

    def test_like_post_func_if_index_out_of_range(self):
        result = self.sm.like_post(3)
        self.assertEqual(result, "Invalid post index.")

    def test_like_post_func_if_not_reached_max_likes(self):
        new_post = {'content': 'some content', 'likes': 0, 'comments': []}
        self.sm._posts.append(new_post)

        result = self.sm.like_post(0)
        self.assertEqual(result, "Post liked by Joe.", result)
        self.assertEqual(self.sm._posts[0]['likes'], 1)

    def test_like_post_func_if_reached_max_likes(self):
        new_post = {'content': 'some content', 'likes': 10, 'comments': []}
        self.sm._posts.append(new_post)

        result = self.sm.like_post(0)
        self.assertEqual(result, "Post has reached the maximum number of likes.")
        self.assertEqual(self.sm._posts[0]['likes'], 10)

    def test_comment_on_post_func_if_len_of_comment_over_10_chars(self):
        new_post = {'content': 'some content', 'likes': 10, 'comments': []}
        self.sm._posts.append(new_post)

        result = self.sm.comment_on_post(0, 'some long comment')
        self.assertEqual(result, "Comment added by Joe on the post.")
        self.assertEqual(self.sm._posts[0]['comments'], [{'user': 'Joe', 'comment': 'some long comment'}])

    def test_comment_on_post_func_if_len_of_comment_under_10_chars(self):
        new_post = {'content': 'some content', 'likes': 10, 'comments': []}
        self.sm._posts.append(new_post)

        result = self.sm.comment_on_post(0,'short')
        self.assertEqual(result, "Comment should be more than 10 characters.")

if __name__ == '__main__':
    main()