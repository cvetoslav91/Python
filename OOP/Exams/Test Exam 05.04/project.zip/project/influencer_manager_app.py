from project.campaigns.high_budget_campaign import HighBudgetCampaign
from project.campaigns.low_budget_campaign import LowBudgetCampaign
from project.influencers.premium_influencer import PremiumInfluencer
from project.influencers.standard_influencer import StandardInfluencer


class InfluencerManagerApp:

    influencers_valid_types = {
        'PremiumInfluencer': PremiumInfluencer,
        'StandardInfluencer': StandardInfluencer
    }

    valid_campaigns = {
        'HighBudgetCampaign': HighBudgetCampaign,
        'LowBudgetCampaign': LowBudgetCampaign,
    }
    def __init__(self):
        self.influencers = []
        self.campaigns = []

    def check_valid_type(self, type):
        if type in self.influencers_valid_types:
            return True
        return False

    def check_username(self, username):
        for infl in self.influencers:
            if infl.username == username:
                return True
        return False

    def register_influencer(self, influencer_type: str, username: str, followers: int, engagement_rate: float):
        if self.check_valid_type(influencer_type):
            if self.check_username(username):
                return f"{username} is already registered."
            else:
                influencer = self.influencers_valid_types[influencer_type](username, followers, engagement_rate)
                self.influencers.append(influencer)
                return f"{username} is successfully registered as a {influencer_type}."
        else:
            return f"{influencer_type} is not an allowed influencer type."

    def check_valid_campaign(self, type):
        if type in self.valid_campaigns:
            return True
        return False

    def check_existing_id(self, id):
        for campaign in self.campaigns:
            if campaign.campaign_id == id:
                return True
        return False

    def create_campaign(self, campaign_type: str, campaign_id: int, brand: str, required_engagement: float):
        if self.check_valid_campaign(campaign_type):
            if self.check_existing_id(campaign_id):
                return f"Campaign ID {campaign_id} has already been created."
            else:
                campaign = self.valid_campaigns[campaign_type](campaign_id, brand, required_engagement)
                self.campaigns.append(campaign)
                return f"Campaign ID {campaign_id} for {brand} is successfully created as a {campaign_type}."
        else:
            return f"{campaign_type} is not a valid campaign type."

    def participate_in_campaign(self, influencer_username: str, campaign_id: int):
        try:
            influencer = next(influencer for influencer in self.influencers if influencer.username == influencer_username)
        except StopIteration:
            return f"Influencer '{influencer_username}' not found."

        try:
            campaign = next(campaign for campaign in self.campaigns if campaign.campaign_id == campaign_id)
        except StopIteration:
            return f"Campaign with ID {campaign_id} not found."

        if campaign.check_eligibility(influencer.engagement_rate):
            if campaign.budget >= influencer.calculate_payment(campaign):
                campaign.approved_influencers.append(influencer)
                campaign.budget -= influencer.calculate_payment(campaign)
                influencer.campaigns_participated.append(campaign)
                return f"Influencer '{influencer_username}' has successfully participated in the campaign with ID {campaign_id}."

        else:
            return f"Influencer '{influencer_username}' does not meet the eligibility criteria for the campaign with ID {campaign_id}."

    def calculate_total_reached_followers(self):
        dictionary = {}
        for campaign in self.campaigns:
            total_followers = 0
            for current_infl in campaign.approved_influencers:
                total_followers += current_infl.reached_followers(campaign.__class__.__name__)
                dictionary[campaign] = total_followers

        return dictionary

    def influencer_campaign_report(self, username: str):
        try:
            influencer = next(influencer for influencer in self.influencers if influencer.username == username)
        except StopIteration:
            return f"{username} has not participated in any campaigns."

        if influencer.campaigns_participated:
            return influencer.display_campaigns_participated()
        return f"{username} has not participated in any campaigns."

    def campaign_statistics(self):
        sorted_campaigns = sorted(self.campaigns, key=lambda x: (len(x.approved_influencers), -x.budget))
        result = '$$ Campaign Statistics $$\n'
        for campaign in sorted_campaigns:
            total_reached_followers = sum([infl.reached_followers(campaign.__class__.__name__) for infl in campaign.approved_influencers])
            result += f'  * Brand: {campaign.brand}, Total influencers: {len(campaign.approved_influencers)}, Total budget: ${campaign.budget:.2f}, Total reached followers: {total_reached_followers}\n'

        return result